import React, { useState } from 'react';

import { FiMenu, FiX } from 'react-icons/fi';

import clsx from 'clsx';
import { NavLink } from 'react-router-dom';
import {
  Divider,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
} from '@material-ui/core';

import { useStyles } from './styless';

const SideBar: React.FC = () => {
  const [open, setOpen] = useState(false);

  const classes = useStyles();
  const handleDrawer = (): void => {
    setOpen(!open);
  };
  return (
    <div className={classes.root}>
      <Drawer
        variant="permanent"
        className={clsx(classes.drawer, {
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open,
        })}
        classes={{
          paper: clsx({
            [classes.drawerOpen]: open,
            [classes.drawerClose]: !open,
          }),
        }}
      >
        <div className={classes.toolbar}>
          <p>{open === true ? 'Re-store' : ''}</p>
          <IconButton onClick={handleDrawer}>
            {open === true ? <FiX /> : <FiMenu />}
          </IconButton>
        </div>
        <Divider />
        <List>
          <NavLink
            to="/addProduct"
            style={{ textDecoration: 'none', color: 'black' }}
          >
            <ListItem button>
              <ListItemIcon />
              <ListItemText primary="Adicionar Produto" />
            </ListItem>
          </NavLink>
          <Divider />
          <NavLink
            to="/listProduct"
            style={{ textDecoration: 'none', color: 'black' }}
          >
            <ListItem button>
              <ListItemIcon />
              <ListItemText primary="Listar Produto" />
            </ListItem>
          </NavLink>
        </List>
      </Drawer>
    </div>
  );
};

export default SideBar;
